# PHP E-Commerce Assignment (Unit 3)

This project demonstrates fundamental PHP programming concepts used in backend web development for e-commerce systems.

## Features
- Reusable functions for modular programming
- Array manipulation using built-in PHP functions
- String processing and text formatting

## Structure

- Section 1: Functions (calculations, formatting, discount logic)
- Section 2: Arrays (sorting, filtering, merging inventories)
- Section 3: Strings (cleaning, analysis, review processing)

## Technologies Used
- PHP 8+
- XAMPP
- Visual Studio Code

## Purpose
This project was developed as part of a Web Programming course to demonstrate structured backend logic and problem-solving using PHP.