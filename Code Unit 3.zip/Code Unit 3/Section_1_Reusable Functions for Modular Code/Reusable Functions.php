<?php

// Calculates total including 10% sales tax
function calculateTotal($price, $quantity) {
    $subtotal = $price * $quantity;
    $tax = $subtotal * 0.10;
    return $subtotal + $tax;
}

// Formats product names
function formatProductName($name) {
    $formatted = trim($name);
    $formatted = ucwords(strtolower($formatted));
    return substr($formatted, 0, 50);
}

// Calculates discount
function calculateDiscount($price, $discountPercent) {
    return $price - ($price * ($discountPercent / 100));
}

// Output
echo "Total Order: $" . calculateTotal(350, 2);
echo PHP_EOL;

echo formatProductName("   wireless bluetooth speaker   ");
echo PHP_EOL;

echo "Discounted Price: $" . calculateDiscount(600, 15);

?>
