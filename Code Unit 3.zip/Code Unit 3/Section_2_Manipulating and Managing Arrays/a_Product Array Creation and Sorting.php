// Product Array Creation and Sorting

<?php

$products = [
["Phone",700],
["Laptop",1200],
["Phone",700],
["Mouse",50]
];

$products = array_unique($products, SORT_REGULAR);

usort($products, function($a,$b){
return $a[1] <=> $b[1];
});

print_r($products);

?>
