//Apply Seasonal Discount to Electronics

<?php

$items = [

["name"=>"Laptop","category"=>"Electronics","price"=>1500],

["name"=>"Chair","category"=>"Furniture","price"=>500],

["name"=>"Tablet","category"=>"Electronics","price"=>800]

];

foreach($items as &$product){

if($product["category"]=="Electronics"){

$product["price"]*=0.90;

}

}

print_r($items);

?>
