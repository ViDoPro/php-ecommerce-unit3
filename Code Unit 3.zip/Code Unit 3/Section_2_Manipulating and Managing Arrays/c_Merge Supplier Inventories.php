//Merge Supplier Inventories

<?php

$supplier1 = ["Laptop","Mouse","Keyboard"];

$supplier2 = ["Mouse","Monitor","Tablet"];

$inventory = array_unique(
array_merge($supplier1,$supplier2)
);

print_r($inventory);

?>
