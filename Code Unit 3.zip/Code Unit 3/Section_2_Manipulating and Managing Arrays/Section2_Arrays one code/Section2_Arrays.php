<?php

echo "SECTION 2A - Product Array Creation and Sorting";
echo PHP_EOL;
echo PHP_EOL;

// Product Array Creation and Sorting
$products = [
["Phone",700],
["Laptop",1200],
["Phone",700],
["Mouse",50]
];

$products = array_unique($products, SORT_REGULAR);

usort($products, function($a,$b){
return $a[1] <=> $b[1];
});

print_r($products);

echo PHP_EOL;
echo "================================";
echo PHP_EOL;
echo PHP_EOL;


echo "SECTION 2B - Apply Seasonal Discount";
echo PHP_EOL;
echo PHP_EOL;

// Apply Seasonal Discount
$items = [

["name"=>"Laptop","category"=>"Electronics","price"=>1500],

["name"=>"Chair","category"=>"Furniture","price"=>500],

["name"=>"Tablet","category"=>"Electronics","price"=>800]

];

foreach($items as &$product){

if($product["category"]=="Electronics"){

$product["price"]*=0.90;

}

}

print_r($items);

echo PHP_EOL;
echo "================================";
echo PHP_EOL;
echo PHP_EOL;


echo "SECTION 2C - Merge Supplier Inventories";
echo PHP_EOL;
echo PHP_EOL;

// Merge Supplier Inventories
$supplier1 = ["Laptop","Mouse","Keyboard"];

$supplier2 = ["Mouse","Monitor","Tablet"];

$inventory =
array_unique(
array_merge($supplier1,$supplier2)
);

print_r($inventory);

?>