<?php

echo "SECTION 3A - Product Description Formatting";
echo PHP_EOL;
echo PHP_EOL;

// a) Product Description Formatting
$description = "HIGH_QUALITY_WIRELESS_HEADPHONES!!!";

$description = strtolower($description);
$description = str_replace("_"," ",$description);
$description = preg_replace("/[^a-zA-Z0-9 ]/","",$description);

echo $description;

echo PHP_EOL;
echo "================================";
echo PHP_EOL;
echo PHP_EOL;


// b) Product Description Analysis
echo "SECTION 3B - Product Description Analysis";
echo PHP_EOL;
echo PHP_EOL;

$text = "This is a high-quality leather wallet with RFID protection.";

echo "Character count: " . strlen($text);
echo PHP_EOL;

echo "Word count: " . str_word_count($text);
echo PHP_EOL;

if(stripos($text,"leather") !== false){
    echo "Keyword found";
} else {
    echo "Keyword not found";
}

echo PHP_EOL;
echo "================================";
echo PHP_EOL;
echo PHP_EOL;


// c) Customer Review Processing
echo "SECTION 3C - Customer Review Processing";
echo PHP_EOL;
echo PHP_EOL;

$review = "Great product! Fast delivery and excellent service.";

echo "Preview: " . substr($review,0,20) . "...";
echo PHP_EOL;

echo "Position of 'excellent': " . strpos($review,"excellent");
echo PHP_EOL;

echo $review . " Thank you for your feedback!";

?>