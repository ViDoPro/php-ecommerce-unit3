//Customer Review Processing

<?php

$review =
"Great product! Fast delivery and excellent service.";

echo substr($review,0,20)."...";

echo "<br>";

echo strpos($review,"excellent");

echo "<br>";

echo $review .
" Thank you for your feedback!";

?>
