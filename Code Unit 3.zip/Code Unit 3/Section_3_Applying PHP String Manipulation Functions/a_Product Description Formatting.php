//Product Description Formatting

<?php

$description =
"HIGH_QUALITY_WIRELESS_HEADPHONES!!!";

$description =
strtolower($description);

$description =
str_replace("_"," ",$description);

$description =
preg_replace(
"/[^a-zA-Z0-9 ]/",
"",
$description
);

echo $description;

?>
