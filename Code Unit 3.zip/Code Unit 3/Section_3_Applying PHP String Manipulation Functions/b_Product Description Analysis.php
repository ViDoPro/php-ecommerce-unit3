//Product Description Analysis

<?php

$text =
"This is a high-quality leather wallet with RFID protection.";

echo strlen($text);

echo "<br>";

echo str_word_count($text);

echo "<br>";

if(stripos($text,"leather")!==false){

echo "Keyword found";

}

else{

echo "Keyword not found";

}

?>
